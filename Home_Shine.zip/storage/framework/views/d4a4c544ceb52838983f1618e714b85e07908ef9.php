<!DOCTYPE html>
<html class="no-js" lang="en">

<!-- belle/home8-jewellery.html   11 Nov 2019 12:30:11 GMT -->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Home Shine Interiors Design & Decoration</title>
    <meta name="description" content="description">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('assets/images/favicon/apple-touch-icon.png' )); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('assets/images/favicon/favicon-32x32.png' )); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/images/favicon/favicon-16x16.png' )); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
    <link rel="manifest" href="/<?php echo e(asset('assets/images/favicon/site.webmanifest')); ?>">

    <!-- Plugins CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins.css ' )); ?>">
    <!-- Bootstap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css' )); ?>">
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css' )); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css' )); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/alertifyjs/css/alertify.min.css' )); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/alertifyjs/css/themes/default.min.css' )); ?>">


    <!---------toaster message -------------->
    <link media="screen" rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

    <style>
        body {
            background-color: #f5f5f5;
        }
    </style>
</head>

<?php echo $__env->make('user.userNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->yieldContent('userWelcome'); ?>
<?php echo $__env->yieldContent('productDetail'); ?>
<?php echo $__env->yieldContent('catagoryProducts'); ?>
<?php echo $__env->yieldContent('shopping_cart'); ?>
<?php echo $__env->yieldContent('checkout'); ?>
<?php echo $__env->yieldContent('userDashboard'); ?>
<?php echo $__env->yieldContent('allProducts'); ?>
<?php echo $__env->yieldContent('wishlist'); ?>
<?php echo $__env->yieldContent('register'); ?>
<?php echo $__env->yieldContent('login'); ?>
<?php echo $__env->yieldContent('blogGrid'); ?>
<?php echo $__env->yieldContent('blogArticle'); ?>
<?php echo $__env->yieldContent('contact'); ?>
<?php echo $__env->yieldContent('services'); ?>
<?php echo $__env->yieldContent('about'); ?>







<?php echo $__env->make('user.userFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Including Jquery -->
<script src="<?php echo e(asset('assets/js/vendor/jquery-3.3.1.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/js/vendor/modernizr-3.6.0.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/js/vendor/jquery.cookie.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/js/vendor/wow.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/js/vendor/instagram-feed.js' )); ?>"></script>
<!-- Including Javascript -->
<script src="<?php echo e(asset('assets/js/bootstrap.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/js/plugins.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/js/popper.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/js/lazysizes.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/js/main.js' )); ?>"></script>

<script src="<?php echo e(asset('assets/alertifyjs/alertify.min.js' )); ?>"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<!--End Instagram Js-->

</html><?php /**PATH C:\xampp\htdocs\AveenirIt_Projects\Home_Shine\resources\views/masterUser.blade.php ENDPATH**/ ?>