
<?php $__env->startSection('services'); ?>
        <!--Body Content-->
        <div id="page-content">
            <!--Page Title-->
            <div class="page section-header text-center">
                <div class="page-title">
                    <div class="wrapper">
                        <h1 class="page-width">FAQs</h1>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-12 col-sm-12 col-md-12 col-lg-12 main-col">
                        <div id="accordionExample">
                            <h2 class="title h2">Pyment and Returns</h2>
                            <div class="faq-body">
                                <h4 class="panel-title" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">What is Lorem Ipsum?</h4>
                                <div id="collapseOne" class="collapse panel-content" data-parent="#accordionExample">Nullam sed neque luctus, maximus diam sed, facilisis orci. Nunc ultricies neque a aliquam sollicitudin. Vivamus sit amet finibus sapien. Duis est dui, sodales nec pretium a, interdum in lacus. Sed et est vel velit vestibulum
                                    tincidunt non a felis. Phasellus convallis, diam eu facilisis tincidunt, ex nibh vulputate dolor, eu maximus massa libero vel eros. In vulputate metus lacus, eu vehicula dolor feugiat id. Nulla vitae nisl in ex consequat
                                    porttitor vel a lectus. Vestibulum viverra in velit ac consequat. Nullam porta nulla eu dignissim cursus.</div>
                            </div>
                            <div class="faq-body">
                                <h4 class="panel-title" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">Why do we use it?</h4>
                                <div id="collapseTwo" class="collapse panel-content">Cras non gravida urna. Ut venenatis nulla in tellus lobortis, vel mollis lectus condimentum. Duis elementum sapien purus, et sagittis nulla efficitur in. Phasellus vitae eros sed nisi fringilla auctor nec quis nunc. Pellentesque
                                    habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Pellentesque rutrum faucibus nibh vitae fermentum. Aliquam commodo sem sit amet malesuada consectetur. Ut sit amet vestibulum diam. Etiam
                                    quis dictum turpis, eget condimentum velit. Sed cursus odio dapibus, consectetur massa sit amet, fringilla purus.</div>
                            </div>
                            <div class="faq-body">
                                <h4 class="panel-title" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">How to use this template?</h4>
                                <div class="panel-content collapse" id="collapseThree">Duis nec nisi id ligula dapibus maximus nec eu dui. Proin ornare, ipsum vitae tincidunt rutrum, diam neque accumsan turpis, a dignissim nisi libero non lacus. Nulla quis massa nulla. Morbi metus lacus, sagittis sed est
                                    vel, aliquet ultrices nibh. Morbi auctor ex eget egestas auctor.</div>
                            </div>
                            <h2 class="title h2">Other Resources</h2>
                            <div class="faq-body">
                                <h4 class="panel-title" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">Integer et erat quis ante tristique lobortis at vel lorem.</h4>
                                <div class="panel-content collapse" id="collapseFour">Proin varius magna rhoncus quam egestas, id faucibus eros viverra. Suspendisse id ipsum at leo congue feugiat non faucibus enim. Suspendisse non hendrerit lorem. Phasellus sit amet nisi dui. Aliquam erat volutpat. Integer
                                    facilisis lacus est, a semper felis iaculis vel. Pellentesque ultrices lorem sed arcu ornare iaculis. Ut pellentesque a dolor ac iaculis. Nullam ac rutrum urna. Ut tempor tempus tincidunt. Sed facilisis ante sed tellus
                                    malesuada fermentum.</div>
                            </div>
                            <div class="faq-body">
                                <h4 class="panel-title" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">Where does it come from?</h4>
                                <div class="panel-content collapse" id="collapseFive">Aliquam erat volutpat. Interdum et malesuada fames ac ante ipsum primis in faucibus. Proin tortor enim, lacinia nec malesuada eget, laoreet eget quam. Suspendisse quis mauris quis tellus rutrum imperdiet nec id ipsum. Suspendisse
                                    non nisi in metus viverra convallis. Nam dictum erat sed libero eleifend, a venenatis ipsum elementum. Nulla placerat metus nec nisl malesuada, et mattis mauris faucibus. Cras blandit efficitur condimentum. Nam euismod
                                    sapien et iaculis tempus. Duis vitae ullamcorper libero.</div>
                            </div>
                            <div class="faq-body">
                                <h4 class="panel-title" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">Why do we use it?</h4>
                                <div class="panel-content collapse" id="collapseSix">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.It is a long established fact that a reader will be distracted by the readable content of a page
                                    when looking at its layout.</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!--End Body Content-->

      

        <!-- Including Jquery -->
        <script src="assets/js/vendor/jquery-3.3.1.min.js"></script>
        <script src="assets/js/vendor/jquery.cookie.js"></script>
        <script src="assets/js/vendor/modernizr-3.6.0.min.js"></script>
        <script src="assets/js/vendor/wow.min.js"></script>
        <!-- Including Javascript -->
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/lazysizes.js"></script>
        <script src="assets/js/main.js"></script>
        <script src="assets/js/cart.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AveenirIt_Projects\Home_Shine\resources\views/services.blade.php ENDPATH**/ ?>